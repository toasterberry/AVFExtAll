# AVFExt

Converter for AVF files used in Her Interactive games (in particular the Nancy Drew series). Credit to Faye/ShimmerFairy for [oldhertools](https://gitlab.com/ShimmerFairy/oldhertools), which helped me figure out most of the format.